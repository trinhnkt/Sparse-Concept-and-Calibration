# B�o c�o chu?n h�a d?nh d?ng b�i b�o theo chu?n JEDM

## Nh?ng file d� ch?nh s?a
- `paper/main_jedm.tex`: �u?c t?o t? `main.tex` v?i c?u tr�c v� d?nh d?ng m?i, thay d?i template, can l? v� tu? ch?nh font ch? theo y�u c?u JEDM. Th�m m?c *Declaration of Generative AI Software Tools* v� *Acknowledgements*, d?ng th?i di chuy?n ph?n Appendix xu?ng sau Bibliography.
- `paper/main_jedm_anonymous.tex`: �u?c t?o ra cho phi�n b?n ?n danh double-blind, ?n th�ng tin t�c gi?, vi?n nghi�n c?u, email v� link github d?nh danh, ?n ph?n Acknowledgements.
- `paper/backup_before_jedm_format/`: �� du?c t?o d? sao luu to�n b? m� ngu?n c?a paper g?c tru?c khi th?c hi?n c�c thay d?i.

## Nh?ng y�u c?u JEDM d� d�p ?ng
- **Kh? gi?y & Can l?**: S? d?ng kh? A4 (`a4paper`), can l? chu?n (tr�i/ph?i 2.75cm, tr�n/du?i 2.25cm) b?ng package `geometry`.
- **Font ch?**: S? d?ng Times Roman 12pt (`\usepackage{mathptmx}`) cho ph?n n?i dung v� sans-serif (Helvetica `\usepackage{helvet}` v� `\usepackage{titlesec}`) cho c�c ti�u d? heading.
- **Tr�nh t? c�c m?c**: C?u tr�c b�i tu�n th?: Abstract, Keywords, n?i dung c�c ph?n (01-06), Declaration of AI Tools, Acknowledgements, References, Appendix. 
- **T�i li?u tham kh?o**: �� c�i d?t `\bibliographystyle{acm}` theo chu?n d?nh d?ng. �� vi?t script ki?m tra t? d?ng v� t?t c? c�c m?c `\cite` trong van b?n d?u kh?p ch�nh x�c v?i `references.bib` (kh�ng c� citation l?i/undefined).
- **B?ng v� H�nh ?nh**: B?ng v� h�nh d� d�ng d�ng `booktabs`, kh�ng du?ng k? d?c. Caption c?a B?ng d?t *b�n tr�n* v� H�nh ?nh d?t *b�n du?i*, nh�n (`\label`) n?m sau caption. S? d?ng `\linewidth` ho?c `\resizebox` d? d?m b?o b?ng/h�nh kh�ng b? tr�n l?.

## Nh?ng l?i LaTeX d� s?a
- C?u tr�c `\appendix` du?c dua v? chu?n v� d?t ? cu?i file c�ng v?i chu?n References b?ng file `acm`.
- X�a b? c�c l?nh d?c t? d�nh ri�ng cho class `IEEEtran` (nhu `\IEEEauthorblockN`, `\IEEEkeywords`) d? tr�nh l?i bi�n d?ch tr�n class standard `article`.

## Nh?ng c?nh b�o c�n l?i
- M�i tru?ng th?c thi thi?u package pdflatex g?c (`pdflatex command not found`) n�n chua bi�n d?ch sinh file PDF tr?c ti?p du?c. T�c gi? c?n bi�n d?ch c?c b? (ch?y `pdflatex`, `bibtex`, `pdflatex`, `pdflatex`) tr�n m�y ho?c upload folder l�n Overleaf d? sinh PDF.

## Nh?ng di?m c?n t�c gi? ki?m tra th? c�ng tru?c khi submit
1. **Bi�n d?ch PDF**: Vui l�ng d�ng l?nh bi�n d?ch d? xu?t PDF v� r� so�t c�c b?ng k�ch thu?c qu� kh? c� th? b? d?n ch? do `\resizebox` thay d?i k�ch thu?c.
2. **Review l?i file Anonymous**: X�c nh?n l?i ph?n ?n danh trong `main_jedm_anonymous.tex` d� d? che gi?u ho�n to�n danh t�nh nh�m t�c gi? chua (t�i d� d?i link github th�nh link ?n danh v� thay th? th�ng tin t�c gi?).
3. **Appendix**: JEDM cho ph�p d?t ph? l?c ? cu?i, nhung xin h�y x�c nh?n l?i xem n� n�n n?m tru?c hay sau `References` n?u bi�n d?ch ra PDF hi?n th? m?c l?c kh�ng nhu �. (T�i d� d?t sau References theo chu?n `article`).

